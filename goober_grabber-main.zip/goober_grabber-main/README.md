Features
> Default:

- Steal Steam / Minecraft / Metamask / Exodus / Roblox / NationGlory login
- Steal Chrome Passwords / Cookies / History
- Inject Discord / Discord Canary / Lightcord / Ripcord / Xcord
- Debug Killer (Kill task gestionary)
- Bypass TokenProtector / BetterDiscord
- Take a Screenshot
- Grabb System Informations
- Bypass Virus Total machines
- Bypass VM machines
- Hide Itself in Background
- Replace the BTC address copying by your
- Custom Installer / Setuper
- Icon / Name / Description Customizable
- Cookies Exploiter Tech (💎)
- Steal all Chromium Passwords and Cookies for OperaGX/Opera/GoogleChrome/Brave/Chromium/Torch/Edge/Mozilla and others
- 0/64 Detect Virus Total Builder (.exe) (💎)
- Grabb Sensitive Files exodus login / a2f backup codes / tokens / passwords... (can be customizable) (💎)



> Injection:

- Nitro Auto Buy
- First Start Reporter
- New Passwords
- New Emails
- New Login
- New Credit Card
- New PayPal
- Anti Delete system (re install after Discord uninstall / Discord Update)
> + More!
